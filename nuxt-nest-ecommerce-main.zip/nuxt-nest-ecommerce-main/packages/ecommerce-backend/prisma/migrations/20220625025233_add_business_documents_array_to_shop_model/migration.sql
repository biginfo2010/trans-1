-- AlterTable
ALTER TABLE "Shop" ADD COLUMN     "businessDocuments" TEXT[];
