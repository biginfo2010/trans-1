'use strict';

/**
 * order-detail controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::order-detail.order-detail');
