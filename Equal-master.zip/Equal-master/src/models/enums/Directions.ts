export enum EDirections {
  UP = 'up',
  DOWN = 'down',
}
