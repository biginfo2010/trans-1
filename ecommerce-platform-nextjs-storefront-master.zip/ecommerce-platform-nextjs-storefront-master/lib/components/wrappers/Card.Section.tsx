'use client';

import { Card } from '@mantine/core';

export default Card.Section;
