<template>
  <div
    class="rounded-lg backdrop-blur-lg bg-gray-400/[0.5] dark:bg-gray-700/[0.5] flex flex-col divide-y divide-gray-400 dark:divide-gray-700"
  >
    <slot />
  </div>
</template>
