---
head:
  - - meta
    - name: og:title
      content: Error Handling
  - - meta
    - name: og:description
      content: "The section on error handling describes different ways of handling errors in different cases."
  - - meta
    - name: og:image
      content: "https://frontends-og-image.vercel.app/Error%20Handling?fontSize=150px"
nav:
  position: 30
---

# Error Handling

:::warning
Deprecated. This doc is based on the old API client. Use The [new API client](/packages/api-client) instead.
:::

How to for error handling in different areas and different cases with examples.

<PageRef page="./error-handling/api-client-error-handling.html" title="API Client" sub="Example how to handle API errors with the API Client" />
