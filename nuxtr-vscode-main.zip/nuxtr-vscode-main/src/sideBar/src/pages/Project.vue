<template>
  <div class="flex w-full flex-col font-inter">
    <Project />
  </div>
</template>
<script setup lang="ts">
import Project from "../components/Project.vue";
</script>
