import CancelPayment from '~/ui/pages/CancelPayment';

export default () => {
    return (
        <div className="lg:w-content mx-auto w-full">
            <CancelPayment />
        </div>
    );
};
