import ComposablesList from "./theme/components/ComposablesList.vue";

export default ({ app }) => {
  app.component("ComposablesList", ComposablesList);
};
