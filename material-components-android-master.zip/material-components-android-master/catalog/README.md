# Material Components Catalog App

The Android version of the Material Design Components Catalog, intended to
demonstrate [Material Design](https://www.material.io) principles and provide
component demonstrations and code examples.
