import { Box } from "@mui/material"
const Logo = () => {
  return <Box component='img' src='/images/bazaar-black-sm.svg' height={60} width={60}/>
}

export default Logo
