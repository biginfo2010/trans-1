<template>
  <div class="container mx-auto">
    <h1 class="h-32 mt-24 text-5xl text-center animate-bounce text-bold">
      Loading ...
    </h1>
  </div>
</template>
