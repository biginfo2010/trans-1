'use client';

import { Burger } from '@mantine/core';

export default Burger;
