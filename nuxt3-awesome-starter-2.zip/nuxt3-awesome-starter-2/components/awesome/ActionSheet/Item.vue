<template>
  <div class="px-4 py-2">
    <slot />
  </div>
</template>
