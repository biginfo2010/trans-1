<template>
  <img
    src="/images/logo/light-background/default.svg"
    alt="Meilisearch"
    class="logo"
  >
</template>

<style scoped>
.logo {
  height: 1.5rem;
}

@media screen and (min-width: 1024px) {
  .logo {
    height: 2.25rem;
  }
}
</style>
