import CInput from './CInput'
export default CInput
