<script setup lang="ts"></script>

<template>
  <div test-id="test-wrapper">
    <NuxtLayout />
  </div>
</template>
