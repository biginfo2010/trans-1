export { default } from './PrivateRoute'
