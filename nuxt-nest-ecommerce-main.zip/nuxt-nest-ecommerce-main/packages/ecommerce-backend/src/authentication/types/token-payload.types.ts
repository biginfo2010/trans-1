export interface TokenPayload {
  userId: number;
}
