module.exports = {
  root: true,
  extends: ['@modern-js'],
};
