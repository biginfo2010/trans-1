<template>
  <div class="flex w-full flex-col font-inter">
    <Modules />
  </div>
</template>
<script setup lang="ts">
import Modules from "../components/Modules.vue";
</script>
