<template>
    <v-skeleton-loader type="card"></v-skeleton-loader>
</template>

<script setup>

</script>