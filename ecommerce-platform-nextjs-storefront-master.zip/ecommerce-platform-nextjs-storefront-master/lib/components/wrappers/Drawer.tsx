'use client';

import { Drawer } from '@mantine/core';

export default Drawer;
