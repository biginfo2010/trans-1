---
"@shopware/nuxt-module": patch
---

Read private shopware config only in SSR context.
