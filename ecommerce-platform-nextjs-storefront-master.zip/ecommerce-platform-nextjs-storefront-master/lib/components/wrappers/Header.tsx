'use client';

import { Header } from '@mantine/core';

export default Header;
