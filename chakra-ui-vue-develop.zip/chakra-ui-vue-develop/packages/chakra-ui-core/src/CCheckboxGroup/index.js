import CCheckboxGroup from './CCheckboxGroup'
export default CCheckboxGroup
