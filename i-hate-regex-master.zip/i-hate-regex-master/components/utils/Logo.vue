<template>
  <nuxt-link to="/">
    <h1 class="text-6xl text-gray-600 align-top">
      i<span class="font-bold text-red-600">Hate</span>Regex
    </h1>
  </nuxt-link>
</template>

<style scoped>
span {
  font-family: 'Fira Sans', sans-serif !important;
  font-weight: 400;
}
.font-bold {
  font-weight: 600;
}
</style>
