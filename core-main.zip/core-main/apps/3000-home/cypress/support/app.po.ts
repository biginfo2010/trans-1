export const getH1 = () => cy.get('h1');
export const getH2 = () => cy.get('h2');
export const getH3 = () => cy.get('h3');
