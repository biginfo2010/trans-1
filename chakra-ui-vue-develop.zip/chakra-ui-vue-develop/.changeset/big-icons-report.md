---
'nuxt-js': patch
'@chakra-ui/vue': patch
'@chakra-ui/nuxt': patch
'@chakra-ui/theme-vue': patch
'chakra-ui-docs': patch
---

Fixes skip link and textarea props
