import en from './en'
import zhHans from './zh-hans'
import zhHant from './zh-hant'

export { en, zhHans, zhHant }
