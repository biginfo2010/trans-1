module.exports = {
  presets: [
    '@vue/app',
    '@babel/preset-env',
    '@vue/babel-preset-jsx'
  ]
}
