Thanks for your pull request! We love contributions.

However, this repository is a read-only export of one boilerplate of its main repository.

If you want to report or contribute, you should instead open your issue on the main repository:

https://github.com/CrystallizeAPI/superfast-boilerplates

PS: if you haven't already, please add tests.
