<template>
  <NuxtLayout name="custom">
    <NuxtPage />
  </NuxtLayout>
</template>
