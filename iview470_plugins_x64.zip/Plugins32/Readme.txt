
- This folder contains some old (32 bit) PlugIn DLLs for (nice) PlugIns which 
  are not available as 64 bit versions.

- These DLLs are called by IrfanView 64 using the Stub-Loader PlugIn
  (Stub_Plugin.exe).

- Do NOT add any other PlugIn DLLs to this folder, they won't be used/called 
  by IrfanView 64.
