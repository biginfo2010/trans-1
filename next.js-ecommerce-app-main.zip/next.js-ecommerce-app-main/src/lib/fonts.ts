import { Open_Sans, Teko } from 'next/font/google';

export const opensans = Open_Sans({ subsets: ['latin'] });
export const teko = Teko({ subsets: ['latin'] });
