function bar(x) {
	foo();
}