export { default } from './NotFound'
