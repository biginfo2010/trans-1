# Changelog

## 0.1.1 - 2020-08-30
### CHANGED:
- Adds More content
    1. Port
    2. DOI
    3. Discord
    4. Hashtags
    5. e.164 Phone
    6. Han Unification

## 0.1.0 - 2020-08-30
### CHANGED:
- Adds Changelog
- Refactors tailwind inline classes into SASS `@apply` rules
