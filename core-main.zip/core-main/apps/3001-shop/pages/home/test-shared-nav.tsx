// @ts-ignore
import TestSharedNav from 'home/pages/home/test-shared-nav';
export default TestSharedNav;
