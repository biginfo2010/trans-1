Thanks for reporting an issue! We love feedback.

However, this repository is a read-only export of one boilerplate of its main repository.

If you want to report or contribute, you should instead open your issue on the main repository:

https://github.com/CrystallizeAPI/superfast-boilerplates

Thank you for your contribution!
