export { default } from './FlashDeals'
