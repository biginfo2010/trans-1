-- AlterTable
ALTER TABLE "User" ADD COLUMN     "currentHashedRefreshToken" TEXT;
