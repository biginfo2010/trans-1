export type RichText = {
    html?: string;
    json?: any;
    plainText?: string;
};
