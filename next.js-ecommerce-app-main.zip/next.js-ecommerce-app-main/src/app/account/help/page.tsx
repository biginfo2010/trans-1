function HelpPage() {
  return <div>help</div>;
}

export default HelpPage;
