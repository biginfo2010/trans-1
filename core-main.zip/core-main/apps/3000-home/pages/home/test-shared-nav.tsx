import SharedNav from '../../components/SharedNav';

export default function TestSharedNav() {
  return (
    <div>
      <SharedNav />
    </div>
  );
}
