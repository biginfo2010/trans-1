module.exports = {
  extends: [
    '@nuxtjs/eslint-config-typescript'
  ],
  ignorePatterns: [
    '/.yarn/',
    '/storybook-static/'
  ]
}
