export { default } from './LiveSearch'
