# Nuxt Nest E-commerce Backend
## Description

This is the backend for a fully functional & enterprise level Multi Vendor E-commerce platform built with NestJS for the server side & NuxtJS for the SSR enabled frontend