import Page from 'checkout/pages/checkout/index';

const Checkout = Page;
Checkout.getInitialProps = Page.getInitialProps;

export default Checkout;
