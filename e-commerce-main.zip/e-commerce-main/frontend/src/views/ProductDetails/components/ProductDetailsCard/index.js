export { default } from './ProductDetailsCard'
