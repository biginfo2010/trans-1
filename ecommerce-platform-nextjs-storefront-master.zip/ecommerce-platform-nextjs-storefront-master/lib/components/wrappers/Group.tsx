'use client';

import { Group } from '@mantine/core';

export default Group;
