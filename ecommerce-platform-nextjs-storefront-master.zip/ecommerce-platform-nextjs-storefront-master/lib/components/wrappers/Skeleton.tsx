'use client';

import { Skeleton } from '@mantine/core';

export default Skeleton;
