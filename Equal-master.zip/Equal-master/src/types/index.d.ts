declare module 'equal-vue'
