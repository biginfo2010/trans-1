'use strict';

module.exports = (val) => JSON.stringify(val, null, 2);
