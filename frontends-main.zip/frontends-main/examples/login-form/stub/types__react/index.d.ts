// stub/types__react/index.d.ts

// Fix for VueDX for HTML template syntax
// https://github.com/johnsoncodehk/volar/discussions/592#discussioncomment-1763880

export type {};
