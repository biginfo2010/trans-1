<template>
  <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3.75 7.23315L10.4506 13.9342L17.1517 7.23325" stroke="#492E6C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
  </svg>
</template>
