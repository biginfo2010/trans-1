import CCloseButton from './CCloseButton'
export default CCloseButton
