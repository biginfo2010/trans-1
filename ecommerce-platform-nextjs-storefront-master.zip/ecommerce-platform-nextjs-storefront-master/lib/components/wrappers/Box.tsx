'use client';

import { Box } from '@mantine/core';

export default Box;
