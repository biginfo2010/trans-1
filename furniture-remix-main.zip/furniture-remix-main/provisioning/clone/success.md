# Next Steps

_Congratualions!_ Project has been installed with success.
The `application` folder contains the `Remix Run` project.

## Running it locally

```sh
$ cd application && npm run dev
```

## Pushin’ `P`

_When ready, you can deploy it easily on [Fly.io](https://fly.io)_

```sh
$ flyctl auth signup
$ flyctl launch --path application
```
