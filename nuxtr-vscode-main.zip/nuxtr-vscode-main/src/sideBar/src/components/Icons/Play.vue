<template>
  <svg
    viewBox="0 0 11 13"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1 1V12L9.9375 6.5L1 1Z"
      stroke="currentColor"
      stroke-width="1.375"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
