<template>
  <svg
    width="9"
    height="8"
    viewBox="0 0 9 8"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3947_169330)">
      <path
        d="M7.125 5.99998C7.47309 5.99998 7.80693 5.87706 8.05307 5.65827C8.29922 5.43948 8.4375 5.14273 8.4375 4.83331C8.4375 4.52389 8.29922 4.22715 8.05307 4.00835C7.80693 3.78956 7.47309 3.66665 7.125 3.66665H6.75C6.80471 3.44996 6.80555 3.22678 6.75245 3.00984C6.69935 2.79291 6.59336 2.58646 6.44053 2.40229C6.2877 2.21812 6.09102 2.05983 5.86173 1.93647C5.63244 1.81311 5.37501 1.72709 5.10416 1.68331C4.83331 1.63954 4.55433 1.63887 4.28316 1.68135C4.01199 1.72383 3.75393 1.80862 3.52372 1.93088C3.05878 2.17781 2.7355 2.56237 2.625 2.99998C2.22523 2.98574 1.83207 3.09011 1.51285 3.29521C1.19362 3.50031 0.96818 3.79338 0.875123 4.12425C0.782066 4.45512 0.827182 4.80321 1.00275 5.1089C1.17831 5.4146 1.4734 5.6589 1.8375 5.79998"
        stroke="currentColor"
        stroke-width="0.666667"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M4.5 4.33333V7.33333"
        stroke="currentColor"
        stroke-width="0.666667"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M3.375 6.33333L4.5 7.33333L5.625 6.33333"
        stroke="currentColor"
        stroke-width="0.666667"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </g>
    <defs>
      <clipPath id="clip0_3947_169330">
        <rect width="9" height="8" fill="currentColor" />
      </clipPath>
    </defs>
  </svg>
</template>
