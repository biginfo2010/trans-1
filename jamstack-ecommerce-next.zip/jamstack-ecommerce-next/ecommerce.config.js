// number of categories to show in the navigation by default
const navItemLength = 5

export {
  navItemLength
}