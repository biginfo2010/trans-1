import { Component } from "React";

class Wow extends Component {
  render() {
    return (
      <div className="wow">
        <p>Here is text</p>
        <input type="number" />
        <LinkBlock />
      </div>
    );
  }
}
