export { default as QuickView } from './QuickView'
