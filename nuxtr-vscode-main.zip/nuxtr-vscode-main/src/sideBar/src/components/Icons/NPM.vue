<template>
    <svg viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5.46126 2H1V11H5.4608V4.2696H7.7304V11H10V2H5.46126Z" fill="currentColor" />
    </svg>
</template>