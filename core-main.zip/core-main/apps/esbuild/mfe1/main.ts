(async () => {
  await import('./bootstrap');
})();
