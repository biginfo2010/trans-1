import ExposedPages from 'checkout/pages/checkout/exposed-pages';
export default ExposedPages;
