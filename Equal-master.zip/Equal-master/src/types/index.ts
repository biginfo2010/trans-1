export { TEmit, TProps } from './global'
