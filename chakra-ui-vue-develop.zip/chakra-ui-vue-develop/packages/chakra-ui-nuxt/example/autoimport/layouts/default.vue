<template>
  <div class="container">
    <c-theme-provider>
      <c-color-mode-provider>
        <c-box font-family="body" as="main">
          <c-reset />
          <Nuxt />
        </c-box>
      </c-color-mode-provider>
    </c-theme-provider>
  </div>
</template>
