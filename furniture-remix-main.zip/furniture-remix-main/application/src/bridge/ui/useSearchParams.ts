import { useSearchParams } from '@remix-run/react';

export default () => {
    return useSearchParams();
};
