package koleton.util

internal const val EMPTY_STRING = ""
internal const val NUMBER_ZERO = 0
internal const val NUMBER_ONE = 1
internal const val WRAPPING_LIMIT = 0.8
