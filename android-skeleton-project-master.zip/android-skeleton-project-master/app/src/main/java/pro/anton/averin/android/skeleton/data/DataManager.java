package pro.anton.averin.android.skeleton.data;

/**
 * Created by AAverin on 01.07.2014.
 */
public class DataManager {

}
