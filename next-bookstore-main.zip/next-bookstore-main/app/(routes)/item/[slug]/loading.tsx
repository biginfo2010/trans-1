import BookDetailsSkeleton from "@/components/loading-ui/BookDetailsSkeleton"

export default function Loading() {
  return <BookDetailsSkeleton />
}
