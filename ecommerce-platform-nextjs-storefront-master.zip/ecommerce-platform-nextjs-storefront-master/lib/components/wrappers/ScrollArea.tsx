'use client';

import { ScrollArea } from '@mantine/core';

export default ScrollArea;
