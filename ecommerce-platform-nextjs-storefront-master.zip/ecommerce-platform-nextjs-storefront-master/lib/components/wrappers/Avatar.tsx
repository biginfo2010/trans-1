'use client';

import { Avatar } from '@mantine/core';

export default Avatar;
