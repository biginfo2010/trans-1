function ErrorCard() {
  return (
    <div className="text-lg font-semibold text-orange-1">
      Something went wrong!! Go back..
    </div>
  );
}

export default ErrorCard;
