export const useExampleHook = ({}) => {
  return [0]
}
