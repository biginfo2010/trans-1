---
"vue-demo-store": minor
---

Added possibility to edit personal info on the checkout process
