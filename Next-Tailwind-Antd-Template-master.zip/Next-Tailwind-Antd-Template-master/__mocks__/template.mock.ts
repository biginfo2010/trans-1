export const MockTemplateFunctionReturn = 'templateFunction'
