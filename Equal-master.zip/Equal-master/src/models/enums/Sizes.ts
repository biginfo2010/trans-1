export enum Sizes {
  BIG = 'big',
  NORMAL = 'normal',
  SMALL = 'small',
}
