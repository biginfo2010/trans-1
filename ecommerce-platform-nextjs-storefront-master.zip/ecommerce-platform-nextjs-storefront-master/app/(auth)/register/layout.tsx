import React from 'react';

export const metadata = {
  title: 'Create account',
};

function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

export default Layout;
