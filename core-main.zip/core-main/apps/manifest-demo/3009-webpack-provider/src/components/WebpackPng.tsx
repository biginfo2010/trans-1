import png from '../../public/webpack.png';

export default function WebpackPng() {
  return (
    <div>
      <img className="remote1-webpack-png" src={png} alt="webpack png" />
    </div>
  );
}
