import { action as StripAction } from './api.webhook.payment.stripe';

/**
 * @deprecated use /stripe instead
 */
export const action = StripAction;
