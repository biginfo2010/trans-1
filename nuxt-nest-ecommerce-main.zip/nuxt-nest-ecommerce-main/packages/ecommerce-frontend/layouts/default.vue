<template>
  <main>
    <slot />
  </main>
</template>
