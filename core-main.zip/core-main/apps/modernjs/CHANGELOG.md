# @module-federation/modernjsapp

## 0.1.81

### Patch Changes

- @module-federation/enhanced@0.8.10

## 0.1.80

### Patch Changes

- Updated dependencies [6e3afc6]
  - @module-federation/enhanced@0.8.9

## 0.1.79

### Patch Changes

- Updated dependencies [eda5184]
  - @module-federation/enhanced@0.8.8

## 0.1.78

### Patch Changes

- Updated dependencies [f573ad0]
- Updated dependencies [336f3d8]
  - @module-federation/enhanced@0.8.7

## 0.1.77

### Patch Changes

- @module-federation/enhanced@0.8.6

## 0.1.76

### Patch Changes

- @module-federation/enhanced@0.8.5

## 0.1.75

### Patch Changes

- @module-federation/enhanced@0.8.4

## 0.1.74

### Patch Changes

- @module-federation/enhanced@0.8.3

## 0.1.73

### Patch Changes

- @module-federation/enhanced@0.8.2

## 0.1.72

### Patch Changes

- @module-federation/enhanced@0.8.1

## 0.1.71

### Patch Changes

- @module-federation/enhanced@0.8.0

## 0.1.70

### Patch Changes

- @module-federation/enhanced@0.7.7

## 0.1.69

### Patch Changes

- @module-federation/enhanced@0.7.6

## 0.1.68

### Patch Changes

- Updated dependencies [5613265]
  - @module-federation/enhanced@0.7.5

## 0.1.67

### Patch Changes

- @module-federation/enhanced@0.7.4

## 0.1.66

### Patch Changes

- @module-federation/enhanced@0.7.3

## 0.1.65

### Patch Changes

- @module-federation/enhanced@0.7.2

## 0.1.64

### Patch Changes

- Updated dependencies [47fdbc2]
  - @module-federation/enhanced@0.7.1

## 0.1.63

### Patch Changes

- Updated dependencies [4eb09e7]
  - @module-federation/enhanced@0.7.0

## 0.1.62

### Patch Changes

- @module-federation/enhanced@0.6.16

## 0.1.61

### Patch Changes

- @module-federation/enhanced@0.6.15

## 0.1.60

### Patch Changes

- Updated dependencies [ad605d2]
  - @module-federation/enhanced@0.6.14

## 0.1.59

### Patch Changes

- @module-federation/enhanced@0.6.13

## 0.1.58

### Patch Changes

- @module-federation/enhanced@0.6.12

## 0.1.57

### Patch Changes

- @module-federation/enhanced@0.6.11

## 0.1.56

### Patch Changes

- Updated dependencies [6b02145]
- Updated dependencies [22a3b83]
  - @module-federation/enhanced@0.6.10

## 0.1.55

### Patch Changes

- Updated dependencies [70a1708]
  - @module-federation/enhanced@0.6.9

## 0.1.54

### Patch Changes

- @module-federation/enhanced@0.6.8

## 0.1.53

### Patch Changes

- Updated dependencies [1b6bf0e]
- Updated dependencies [9e32644]
- Updated dependencies [9e32644]
- Updated dependencies [9e32644]
  - @module-federation/enhanced@0.6.7

## 0.1.52

### Patch Changes

- @module-federation/enhanced@0.6.6

## 0.1.51

### Patch Changes

- @module-federation/enhanced@0.6.5

## 0.1.50

### Patch Changes

- @module-federation/enhanced@0.6.4

## 0.1.49

### Patch Changes

- @module-federation/enhanced@0.6.3

## 0.1.48

### Patch Changes

- @module-federation/enhanced@0.6.2

## 0.1.47

### Patch Changes

- Updated dependencies [2855583]
- Updated dependencies [2855583]
  - @module-federation/enhanced@0.6.1

## 0.1.46

### Patch Changes

- Updated dependencies [f245bb3]
- Updated dependencies [1d9bb77]
  - @module-federation/enhanced@0.6.0

## 0.1.45

### Patch Changes

- Updated dependencies [b90fa7d]
  - @module-federation/enhanced@0.5.2

## 0.1.44

### Patch Changes

- @module-federation/enhanced@0.5.1

## 0.1.43

### Patch Changes

- @module-federation/enhanced@0.5.0

## 0.1.42

### Patch Changes

- Updated dependencies [a335707]
  - @module-federation/enhanced@0.4.0

## 0.1.41

### Patch Changes

- Updated dependencies [59db2fd]
  - @module-federation/enhanced@0.3.5

## 0.1.40

### Patch Changes

- @module-federation/enhanced@0.3.4

## 0.1.39

### Patch Changes

- 85c6a12: fix: support rspack ssr live reload
  - @module-federation/enhanced@0.3.3

## 0.1.38

### Patch Changes

- Updated dependencies [85ae159]
  - @module-federation/enhanced@0.3.2

## 0.1.37

### Patch Changes

- @module-federation/enhanced@0.3.1

## 0.1.36

### Patch Changes

- Updated dependencies [fa37cc4]
  - @module-federation/enhanced@0.3.0

## 0.1.35

### Patch Changes

- @module-federation/enhanced@0.2.8

## 0.1.34

### Patch Changes

- Updated dependencies [b00ef13]
  - @module-federation/enhanced@0.2.7

## 0.1.33

### Patch Changes

- Updated dependencies [4488064]
  - @module-federation/enhanced@0.2.6

## 0.1.32

### Patch Changes

- @module-federation/enhanced@0.2.5

## 0.1.31

### Patch Changes

- @module-federation/enhanced@0.2.4

## 0.1.30

### Patch Changes

- @module-federation/enhanced@0.2.3

## 0.1.29

### Patch Changes

- @module-federation/enhanced@0.2.2

## 0.1.28

### Patch Changes

- Updated dependencies [88445e7]
  - @module-federation/enhanced@0.2.1

## 0.1.27

### Patch Changes

- @module-federation/enhanced@0.2.0

## 0.1.26

### Patch Changes

- Updated dependencies [1e93c5e]
  - @module-federation/enhanced@0.1.21

## 0.1.25

### Patch Changes

- Updated dependencies [766de80]
- Updated dependencies [d5ac542]
  - @module-federation/enhanced@0.1.20

## 0.1.24

### Patch Changes

- Updated dependencies [e1518e2]
  - @module-federation/enhanced@0.1.19

## 0.1.23

### Patch Changes

- @module-federation/enhanced@0.1.18

## 0.1.22

### Patch Changes

- @module-federation/enhanced@0.1.17

## 0.1.21

### Patch Changes

- @module-federation/enhanced@0.1.16

## 0.1.20

### Patch Changes

- @module-federation/enhanced@0.1.15

## 0.1.19

### Patch Changes

- @module-federation/enhanced@0.1.14

## 0.1.18

### Patch Changes

- Updated dependencies [0113b81]
  - @module-federation/enhanced@0.1.13

## 0.1.17

### Patch Changes

- @module-federation/enhanced@0.1.12

## 0.1.16

### Patch Changes

- Updated dependencies [d45ee54]
- Updated dependencies [3d2c63a]
  - @module-federation/enhanced@0.1.11

## 0.1.15

### Patch Changes

- @module-federation/enhanced@0.1.10

## 0.1.14

### Patch Changes

- Updated dependencies [fcbae83]
  - @module-federation/enhanced@0.1.9

## 0.1.13

### Patch Changes

- Updated dependencies [56eb56a]
- Updated dependencies [b120511]
  - @module-federation/enhanced@0.1.8

## 0.1.12

### Patch Changes

- Updated dependencies [648353b]
  - @module-federation/enhanced@0.1.7

## 0.1.11

### Patch Changes

- Updated dependencies [72c7b80]
  - @module-federation/enhanced@0.1.6

## 0.1.10

### Patch Changes

- Updated dependencies [876a4ff]
- Updated dependencies [e0acf83]
- Updated dependencies [1a9c6e7]
  - @module-federation/enhanced@0.1.5

## 0.1.9

### Patch Changes

- Updated dependencies [8f3a440]
- Updated dependencies [2f697b9]
- Updated dependencies [8f3a440]
  - @module-federation/enhanced@0.1.4

## 0.1.8

### Patch Changes

- Updated dependencies [32eba3c]
- Updated dependencies [6b3b210]
  - @module-federation/enhanced@0.1.3

## 0.1.7

### Patch Changes

- Updated dependencies [c1efbbf]
- Updated dependencies [c8c0ad2]
- Updated dependencies [1bb03d1]
- Updated dependencies [1bb03d1]
  - @module-federation/enhanced@0.1.2

## 0.1.6

### Patch Changes

- Updated dependencies [ee57fb0]
  - @module-federation/enhanced@0.1.1

## 0.1.5

### Patch Changes

- Updated dependencies [df3ef24]
- Updated dependencies [df3ef24]
- Updated dependencies [df3ef24]
  - @module-federation/enhanced@0.1.0

## 0.1.4

### Patch Changes

- @module-federation/enhanced@0.0.17

## 0.1.3

### Patch Changes

- @module-federation/enhanced@0.0.16

## 0.1.2

### Patch Changes

- Updated dependencies [ba5bedd]
  - @module-federation/enhanced@0.0.15

## 0.1.1

### Patch Changes

- @module-federation/enhanced@0.0.14
