package koleton.sample.utils

const val DEFAULT_DELAY: Long = 3000
const val DEFAULT_PAGE_SIZE: Int = 10
const val ITEM_COUNT: Int = 3