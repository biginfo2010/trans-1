'use client';

import { Divider } from '@mantine/core';

export default Divider;
