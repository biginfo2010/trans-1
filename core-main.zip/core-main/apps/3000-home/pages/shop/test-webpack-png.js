import TestPng from 'shop/pages/shop/test-webpack-png';
export default TestPng;
