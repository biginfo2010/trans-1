<template>
  <div class="main-content">
    <nuxt />
  </div>
</template>
