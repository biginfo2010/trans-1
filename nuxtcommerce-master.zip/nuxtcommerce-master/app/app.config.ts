export default defineAppConfig({
  siteName: 'NuxtCommerce',
  ui: {
    primary: 'red',
    gray: 'neutral',
  },
});
