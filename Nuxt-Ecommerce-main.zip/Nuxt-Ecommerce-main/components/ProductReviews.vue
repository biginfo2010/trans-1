<template>
  <div>
    <hr class="my-10" />
    <p>Product Reviews Here</p>
  </div>
</template>
