export { default } from './Minimal'
