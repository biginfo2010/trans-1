export default function Footer() {
	return (
		<div className={'container mt-5 mb-4'}>
			<footer className={'p-2 border-top'}>
				This is footer.
			</footer>
		</div>
	);
}
