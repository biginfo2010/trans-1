export type CrystallizePropertiesTable = {
    title: string;
    properties: Record<string, string>;
};
