import { FC } from "react"

interface IProps { }

const Template: FC<IProps> = ({ }: IProps) => {
  return (
    <div></div>
  )
}

export default Template
