declare module 'mfe1/*';
