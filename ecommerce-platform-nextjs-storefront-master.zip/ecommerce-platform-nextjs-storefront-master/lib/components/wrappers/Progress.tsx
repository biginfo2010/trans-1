'use client';

import { Progress } from '@mantine/core';

export default Progress;
