export default defineAppConfig({
  ecommerce: {
    indexName: 'amazon-products'
  }
})
