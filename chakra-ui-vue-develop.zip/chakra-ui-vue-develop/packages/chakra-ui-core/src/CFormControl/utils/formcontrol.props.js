export const formControlProps = {
  isInvalid: Boolean,
  isRequired: Boolean,
  isDisabled: Boolean,
  isReadOnly: Boolean
}
