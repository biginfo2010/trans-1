import { useNavigation } from '@remix-run/react';

export default () => {
    return useNavigation();
};
