# useCheckout example

This example should help get you started developing [Shopware Frontends](https://github.com/shopware/frontends).

## Customization

- edit [./app.vue](./app.vue) in order to change the current example

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
