<template>
  <svg
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3947_168996)">
      <path
        d="M2 9.67545L2.54167 8.05045C2.07352 7.35806 1.90416 6.53812 2.06509 5.74307C2.22602 4.94803 2.70628 4.23198 3.41657 3.72806C4.12686 3.22415 5.01886 2.96666 5.9267 3.00346C6.83455 3.04027 7.69647 3.36888 8.3522 3.92818C9.00794 4.48748 9.41286 5.23942 9.49169 6.04419C9.57053 6.84896 9.3179 7.65179 8.78078 8.30342C8.24366 8.95504 7.45861 9.41112 6.57158 9.58684C5.68455 9.76257 4.75592 9.64599 3.95833 9.25878L2 9.67545Z"
        stroke="currentColor"
        stroke-width="0.833333"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </g>
    <defs>
      <clipPath id="clip0_3947_168996">
        <rect width="12" height="12" fill="currentColor" />
      </clipPath>
    </defs>
  </svg>
</template>
