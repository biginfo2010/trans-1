export interface VerificationTokenPayload {
  email: string;
}
