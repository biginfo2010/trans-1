export default {
  wip: '这个页面正在进行中',
  own_theme_copy: '要创建自己的主题，可以复制初始主题文件并对其进行修改：',
  own_theme: '或者从头开始创建你自己的主题文件',
  full: '包含亮色和暗色主题的class',
  light: '包含亮色主题的class',
  dark: '包含暗色主题的class',
}
