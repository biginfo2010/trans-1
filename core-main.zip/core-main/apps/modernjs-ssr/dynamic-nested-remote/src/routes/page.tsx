import Content from '../components/Content';
import './index.css';

const Index = () => (
  <div className="container-box">
    <Content />
  </div>
);

export default Index;
