// Here we shall have files functions that manipulate colors based on the theme on a per component basis
/**
 * An example would be in the `Badge` component
 * ```js
 * import { addOpacity } from '@/lib/theme/utils'
 * let foo = addOpacity('green')
 * ```
 */
