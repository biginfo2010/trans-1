module.exports = 'module from node-dynamic-remote-new-version';
