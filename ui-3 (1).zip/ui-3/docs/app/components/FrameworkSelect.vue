<script setup lang="ts">
const { framework, frameworks } = useSharedData()

const value = ref<string | undefined>(undefined)

onMounted(() => {
  value.value = framework.value
})

watch(framework, () => {
  value.value = framework.value
})
</script>

<template>
  <UTabs
    v-model="value"
    :items="frameworks"
    :content="false"
    color="neutral"
    :ui="{
      indicator: 'bg-(--ui-bg)',
      trigger: 'px-1 data-[state=active]:text-(--ui-text-highlighted)'
    }"
    size="sm"
    @update:model-value="(framework = $event as string)"
  />
</template>
