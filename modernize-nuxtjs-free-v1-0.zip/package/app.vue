<template>
  <NuxtExampleLayout >
    <NuxtLoadingIndicator />
    <NuxtLayout>
      <NuxtPage/>
    </NuxtLayout>
  </NuxtExampleLayout>
</template>