<template>
  <div class="max-w-7xl mx-auto">
    <h1>Example: Modal with Teleport</h1>
    <ul>
      <li>
        <NuxtLink to="/">Home</NuxtLink>
      </li>
      <li>
        <NuxtLink to="/team">Team</NuxtLink>
      </li>
      <li>
        <NuxtLink to="/wishlist">Wishlist</NuxtLink>
      </li>
    </ul>
    <NuxtPage />
  </div>
</template>
