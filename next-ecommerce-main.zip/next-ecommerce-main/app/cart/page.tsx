import Cart from "@/components/Cart";
import React from "react";

export default function CartPage() {
  return <Cart />;
}
