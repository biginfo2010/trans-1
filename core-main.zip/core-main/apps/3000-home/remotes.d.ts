declare module 'shop/useCustomRemoteHook';
declare module 'shop/WebpackSvg';
declare module 'shop/WebpackPng';
declare module 'checkout/CheckoutTitle';
declare module 'checkout/ButtonOldAnt';
