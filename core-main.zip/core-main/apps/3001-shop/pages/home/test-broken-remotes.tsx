// @ts-ignore
import TestBrokenRemotes from 'home/pages/home/test-broken-remotes';
export default TestBrokenRemotes;
