export { default } from './TopRatings'
