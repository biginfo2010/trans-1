export interface Item {
    id: number;
    name: string;
    price: number;
    description: string;
    // Add more properties as needed
}