<template>
    <footer class="pt-5" style="background: rgb(255, 255, 255); border-top: 5px solid rgb(230 74 26);">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-5 mb-4">
                    <h4 class="font-weight-bold">ABOUT</h4>
                    <hr style="border-top: 3px solid rgb(226, 232, 240); border-radius: 0.5rem;">
                    <p> Trusted Official Shoes Store in Indonesia. Safe and
                        &amp; Lowest Price! Shop now. </p>
                </div>
                <div class="col-md-3 mb-4">
                    <h4 class="font-weight-bold">PAYMENT METHODS</h4>
                    <hr style="border-top: 3px solid rgb(226, 232, 240); border-radius: 0.5rem;">
                    <div class="row">
                        <div class="col-md-4 col-4 mb-3">
                            <div class="card rounded">
                                <div class="card-body p-2 text-center"><img src="/images/payment/BCA.png" style="width: 50px;"></div>
                            </div>
                        </div>
                        <div class="col-md-4 col-4 mb-3">
                            <div class="card rounded">
                                <div class="card-body p-2 text-center"><img src="/images/payment/BNI.png" style="width: 45px;"></div>
                            </div>
                        </div>
                        <div class="col-md-4 col-4 mb-3">
                            <div class="card rounded">
                                <div class="card-body p-2 text-center"><img src="/images/payment/BRI.png" style="width: 60px;"></div>
                            </div>
                        </div>
                        <div class="col-md-4 col-4 mb-3">
                            <div class="card rounded">
                                <div class="card-body p-2 text-center"><img src="/images/payment/GOPAY.png" style="width: 60px;"></div>
                            </div>
                        </div>
                        <div class="col-md-4 col-4 mb-3">
                            <div class="card rounded">
                                <div class="card-body p-2 text-center"><img src="/images/payment/indomaret-logo.png"
                                        style="width: 60px;">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-4 mb-3">
                            <div class="card rounded">
                                <div class="card-body p-2 text-center"><img src="/images/payment/atm-bersama.jpg" style="width: 40px;"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h4 class="font-weight-bold">OPERATING HOURS</h4>
                    <hr style="border-top: 3px solid rgb(226, 232, 240); border-radius: 0.5rem;">
                    <p><i class="fa fa-clock"></i> Store Open Every Day:
                        <br><br> <strong>Monday - Friday</strong> ( 07.00 s/d
                        19.00 ) <br> <strong>Saturday - Sunday</strong> ( 07.00 s/d
                        16.00 )
                    </p>
                </div>
            </div>
            <div class="row text-center mt-3 pb-3">
                <div class="col-md-12">
                    <hr> © <strong>RIZKI NUGROHOO</strong> 2024 • Hak Cipta Dilindungi
                </div>
            </div>
        </div>
    </footer>
</template>
<script>
export default {
}
</script>
<style></style>
