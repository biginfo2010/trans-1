import CAspectRatioBox from './CAspectRatioBox'
export default CAspectRatioBox
