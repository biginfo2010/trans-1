---
type: tutorial
mainCommand: ["npm run dev", "Starting http server"]
prepareCommands:
  - ["npm install", "Installing dependencies"]
---
