declare module 'remote1/useCustomRemoteHook';
declare module 'remote1/WebpackSvg';
declare module 'remote1/WebpackPng';
declare module 'manifest-provider/Component';
declare module 'js-entry-provider/Component';
declare module 'dynamic-remote/ButtonOldAnt';
