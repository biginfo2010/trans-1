import { existsSync, readdirSync } from 'node:fs';
import { dirname, extname, join, sep } from 'pathe';
import * as vscode from 'vscode';

const EXTENSIONS = new Set(['.vue', '.js', '.ts']);
const DIR_SEPARATOR = sep;
const SCOPED_DIRECTORIES = new Set(['components', 'layouts', 'pages', 'composables', 'middleware']);

export class NuxtIgnoreCompletionProvider implements vscode.CompletionItemProvider {
    provideCompletionItems (
        document: vscode.TextDocument,
        position: vscode.Position,
    ): vscode.ProviderResult<vscode.CompletionItem[] | vscode.CompletionList> {
        try {
            const lineText = document.lineAt(position).text;
            const currentDirectory = dirname(document.fileName);

            if (position.character === lineText.length) {
                const textBeforeCursor = lineText.slice(0, Math.max(0, position.character));
                const pathSeparatorIndex = textBeforeCursor.lastIndexOf(DIR_SEPARATOR);

                if (pathSeparatorIndex !== -1) {
                    const userTypedPath = textBeforeCursor.slice(0, Math.max(0, pathSeparatorIndex));
                    const targetDirectory = join(currentDirectory, userTypedPath);
                    const subDirectories = this.getSubDirectories(targetDirectory);

                    return this.createCompletionItems(subDirectories);
                } else if (textBeforeCursor.endsWith('!')) {
                    const parts = textBeforeCursor.split('!');
                    const userTypedPath = parts[0];
                    // @ts-ignore
                    const targetDirectory = join(currentDirectory, userTypedPath);
                    const subDirectories = this.getSubDirectories(targetDirectory);

                    return this.createCompletionItems(subDirectories);
                } else {
                    const topLevelSubDirectories = this.getTopLevelSubDirectories(currentDirectory);
                    return this.createCompletionItems(topLevelSubDirectories);
                }
            }
        } catch (error) {
            this.logError(error);
        }

        return [];
    }

    private createCompletionItems (directories: string[]): vscode.CompletionItem[] {
        return directories.map(subDir => {
            const type = this.getCompletionItemType(subDir);
            const item = new vscode.CompletionItem(subDir, type);

            if (type === vscode.CompletionItemKind.Folder) {
                item.insertText = new vscode.SnippetString(subDir);
            }

            return item;
        });
    }

    private getCompletionItemType (name: string): vscode.CompletionItemKind {
        const extension = extname(name);
        return EXTENSIONS.has(extension) ? vscode.CompletionItemKind.File : vscode.CompletionItemKind.Folder;
    }

    private getSubDirectories (directory: string): string[] {
        directory = directory.replace(/!/g, '');

        try {
            if (existsSync(directory)) {
                return readdirSync(directory, { withFileTypes: true })
                    .filter(dirent => dirent.isDirectory() || EXTENSIONS.has(extname(dirent.name)))
                    .map(dirent => dirent.name);
            }
        } catch (error) {
            this.logError(error);
        }

        return [];
    }

    private getTopLevelSubDirectories (directory: string): string[] {
        return this.getSubDirectories(directory).filter(subDir => SCOPED_DIRECTORIES.has(subDir));
    }

    private logError (error: any): void {
        console.error(error);
    }
}
