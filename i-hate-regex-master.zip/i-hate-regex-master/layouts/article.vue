<template>
  <post>
    <article class="article-layout">
      <nuxt></nuxt>
    </article>
  </post>
</template>

<script>
import post from "~/components/layouts/base/post";

export default {
    components: {
        post
    }
}
</script>

<style>

</style>