module.exports = {
  trailingComma: 'all',
  singleQuote: true,
  endOfLine: 'auto',
  htmlWhitespaceSensitivity: 'ignore',
  semi: false,
  plugins: [require('prettier-plugin-tailwindcss')]
}
