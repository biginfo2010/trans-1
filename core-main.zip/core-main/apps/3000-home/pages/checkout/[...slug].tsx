// @ts-ignore
import SlugRoute from 'checkout/pages/checkout/[...slug]';
export default SlugRoute;
