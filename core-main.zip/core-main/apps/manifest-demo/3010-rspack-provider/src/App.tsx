import LocalButton from './Button';
import { Await } from 'react-router-dom';
console.log(Await);

const App = () => (
  <div>
    <h1>Bi-Directional</h1>
    <h2>App 2</h2>
    <LocalButton />
  </div>
);

export default App;
