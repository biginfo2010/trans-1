<script lang="ts" setup></script>

<template>
  <div class="container mt-4">
    <div class="row justify-content-md-center">
      <div class="col-xs-12 col-md-6">
        <slot />
      </div>
    </div>
  </div>
</template>

<style scoped></style>
