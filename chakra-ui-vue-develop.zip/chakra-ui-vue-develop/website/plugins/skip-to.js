import Vue from 'vue'
import VueSkipTo from '@vue-a11y/skip-to'

Vue.use(VueSkipTo)
