<template>
  <div class="it-divider" :class="{}" role="separator"></div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'it-datepicker',
  props: {},
})
</script>
