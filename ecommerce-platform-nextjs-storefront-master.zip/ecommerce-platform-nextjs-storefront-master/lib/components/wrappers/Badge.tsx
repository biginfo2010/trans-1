'use client';

import { Badge } from '@mantine/core';

export default Badge;
