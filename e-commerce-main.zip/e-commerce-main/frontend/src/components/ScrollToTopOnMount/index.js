export { default } from './ScrollToTopOnMount'
