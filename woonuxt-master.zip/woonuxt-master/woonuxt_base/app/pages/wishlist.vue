<template>
  <WishList />
</template>
