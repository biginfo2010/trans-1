---
"docs": patch
---

Added warning about media URL for Shopware Endpoint on the SSR mode section
