-- DropEnum
DROP TYPE "PaymentMethod";
