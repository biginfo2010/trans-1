'use client';

import { Center } from '@mantine/core';

export default Center;
