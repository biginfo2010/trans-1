export { default } from './SliderArrow'
