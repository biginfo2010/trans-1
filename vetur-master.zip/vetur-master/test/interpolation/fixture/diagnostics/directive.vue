<template>
  <div v-show="foo || bar">v-show test</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  data() {
    return {
      foo: false
    }
  }
})
</script>

