export { default as ProductDetailsCard } from './ProductDetailsCard'
export { default as AdditionalInfo } from './AdditionalInfo'
