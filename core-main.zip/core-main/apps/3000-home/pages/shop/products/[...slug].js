import ProductPage from 'shop/pages/shop/products/[...slug]';
export default ProductPage;
