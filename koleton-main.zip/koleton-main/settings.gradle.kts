rootProject.buildFileName = "build.gradle.kts"
include(":koleton-base", "koleton-singleton", ":koleton-sample")
