export const TAX_RATE = 0.15; // 15%
export const FREE_SHIPPING_THRESHOLD = 100;
