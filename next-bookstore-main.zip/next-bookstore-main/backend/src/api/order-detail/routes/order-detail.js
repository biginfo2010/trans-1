'use strict';

/**
 * order-detail router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::order-detail.order-detail');
