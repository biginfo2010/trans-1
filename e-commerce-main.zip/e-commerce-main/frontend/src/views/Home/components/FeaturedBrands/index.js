export { default } from './FeaturedBrands'
