<template>
  <div class="px-20">
    <TheHeader />
    <slot />
    <TheFooter />
  </div>
</template>