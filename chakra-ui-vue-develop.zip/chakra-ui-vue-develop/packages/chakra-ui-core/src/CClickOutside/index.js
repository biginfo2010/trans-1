import CClickOutside from './CClickOutside'
export default CClickOutside
