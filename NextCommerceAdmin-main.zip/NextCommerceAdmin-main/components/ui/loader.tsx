"use client";

import { ClipLoader } from "react-spinners";

export const Loader = () => {
  return <ClipLoader color="#3498db" size={50} />
};
