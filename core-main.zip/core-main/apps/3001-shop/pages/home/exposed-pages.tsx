//@ts-ignore
import ExposedPages from 'home/pages/home/exposed-pages';

export default ExposedPages;
