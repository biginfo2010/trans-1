<template>
  <div class="py-2">
    <slot />
  </div>
</template>
