//@ts-nocheck

(async () => {
  import('./bootstrap');
})();
