import CBadge from './CBadge'
export default CBadge
