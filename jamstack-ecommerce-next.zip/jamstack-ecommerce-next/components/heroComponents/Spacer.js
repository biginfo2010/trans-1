const Spacer = ({ width }) => (
  <div className={`m-${width}`} />
)

export default Spacer