export { default } from './CardDetails'
