---
head:
  - - meta
    - name: og:title
      content: Digital Sales Rooms
  - - meta
    - name: og:description
      content: "Get insights into the Digital Sales Rooms template created with Composable Frontends."
  - - meta
    - name: og:image
      content: "https://frontends-og-image.vercel.app/Digital%20Sales%20Rooms.png?fontSize=120px"
nav:
  position: 40
---

# Digital Sales Rooms

The Customer Documentation about the Admin Extension for Digital Sales Rooms can be found [here](https://docs.shopware.com/en/shopware-6-en/extensions/digital-sales-rooms).
