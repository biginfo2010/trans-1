export { default } from './TopInfoBar'
