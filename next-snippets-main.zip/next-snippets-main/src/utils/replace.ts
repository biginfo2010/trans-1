export const fileNameCapitalizedReplace = "${1:${TM_FILENAME_BASE/(.)/${1:/upcase}/}}";
export const fileNameReplace = "";
export const firstReplace = "${1}";
export const secondReplace = "${2}";
export const thirdReplace = "${3}";

export const fileNameCapitalizedReplaceMd = "FileName";
export const fileNameReplaceMd = "filename";
export const firstReplaceMd = "";
export const secondReplaceMd = "";
export const thirdReplaceMd = "";
