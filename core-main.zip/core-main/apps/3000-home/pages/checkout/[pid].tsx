// @ts-ignore
import Pid from 'checkout/pages/checkout/[pid]';
export default Pid;
