export type SEO = {
    title: string;
    description?: string;
    image?: string;
};
