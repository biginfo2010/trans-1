module.exports = {
  process() {
    return ""
  },
}
