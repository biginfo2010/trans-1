'use client';

import { Stack } from '@mantine/core';

export default Stack;
