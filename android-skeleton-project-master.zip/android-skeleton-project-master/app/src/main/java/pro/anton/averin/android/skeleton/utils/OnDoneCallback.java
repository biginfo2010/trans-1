package pro.anton.averin.android.skeleton.utils;

/**
 * Created by AAverin on 29.06.2014.
 */
public interface OnDoneCallback {
    public void onDone(boolean success, Object data);
}
