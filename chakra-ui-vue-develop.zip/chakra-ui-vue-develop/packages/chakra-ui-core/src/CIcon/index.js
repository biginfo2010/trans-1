import CIcon from './CIcon'
export default CIcon
