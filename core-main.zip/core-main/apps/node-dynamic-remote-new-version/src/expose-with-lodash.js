const lodash = require('lodash');
module.exports = function () {
  return Object.keys(lodash);
};
