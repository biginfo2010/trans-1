import Home from 'home/pages/index';
export default Home;
