**Internet Protocol (ip)** addresses are the numerical identifiers of each device connected to a computer network that uses Internet Protocol for communication. This 32 bit address scheme is the first version of ip addresses.

The addresses are separated by period `(.)`.

ip addresses are of the range `0.0.0.0` - `255.255.255.255`

This expression will match a given string for an ip address and also considers the range.