'use client';

import { Table } from '@mantine/core';

export default Table;
