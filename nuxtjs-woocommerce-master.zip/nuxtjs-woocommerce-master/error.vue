<template>
  <main>
    <h1>Page not found</h1>
    <ul role="list">
      There was an error locating the page
    </ul>
  </main>
</template>
