<script lang="ts" setup></script>

<template>
  <TheHeader />

  <main class="container my-3">
    <slot />
  </main>
  <TheFooter />
</template>

<style scoped></style>
