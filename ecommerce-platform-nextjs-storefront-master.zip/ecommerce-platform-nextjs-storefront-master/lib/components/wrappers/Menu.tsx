'use client';

import { Menu } from '@mantine/core';

export default Menu;
