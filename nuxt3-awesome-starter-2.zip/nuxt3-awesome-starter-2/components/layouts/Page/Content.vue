<template>
  <div
    class="flex w-full pt-[64px]"
    :style="{ 'min-height': 'var(--layout-page-content-min-height)' }"
  >
    <slot />
  </div>
</template>
