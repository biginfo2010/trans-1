<template>
  <svg
    viewBox="0 0 12 13"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M6 1L11 3.8125V9.4375L6 12.25L1 9.4375V3.8125L6 1Z"
      stroke="currentColor"
      stroke-width="0.8"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6 6.625L11 3.8125"
      stroke="currentColor"
      stroke-width="0.8"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6 6.625V12.25"
      stroke="currentColor"
      stroke-width="0.8"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6 6.625L1 3.8125"
      stroke="currentColor"
      stroke-width="0.8"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
