<script lang="ts" setup>
import { HollowDotsSpinner } from 'epic-spinners'
</script>

<template>
  <HollowDotsSpinner
    :animation-duration="1000"
    :dot-size="15"
    :dots-num="3"
    color="#FF5CAA"
  />
</template>
