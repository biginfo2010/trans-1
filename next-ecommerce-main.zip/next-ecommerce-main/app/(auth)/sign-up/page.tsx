export default function SignUpPage() {
  return <div>SignUpPage</div>;
}
