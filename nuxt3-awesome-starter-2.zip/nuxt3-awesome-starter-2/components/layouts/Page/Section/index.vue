<template>
  <div class="pt-2 mb-6">
    <slot />
  </div>
</template>
