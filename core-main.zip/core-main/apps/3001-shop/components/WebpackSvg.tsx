import svg from '../public/webpack.svg';

export default function WebpackSvg() {
  return <img src={svg.src} alt="webpack svg" />;
}
