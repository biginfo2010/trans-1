const classes: { readonly 'test-remote2': string };

export default classes;
