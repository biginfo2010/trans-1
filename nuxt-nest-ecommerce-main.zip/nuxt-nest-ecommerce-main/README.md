# Nuxt Nest E-commerce
## Description

A fully functional & enterprise level Multi Vendor E-commerce platform built with NestJS for the server side & NuxtJS for the SSR enabled frontend