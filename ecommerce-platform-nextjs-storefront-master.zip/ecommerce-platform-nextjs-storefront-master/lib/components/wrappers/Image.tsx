'use client';

import { Image } from '@mantine/core';

export default Image;
