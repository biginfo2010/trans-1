-- AlterTable
ALTER TABLE "UserProductReview" ADD COLUMN     "images" TEXT[];

-- AlterTable
ALTER TABLE "UserShopReview" ADD COLUMN     "images" TEXT[];
