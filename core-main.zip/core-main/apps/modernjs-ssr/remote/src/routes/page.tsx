// @ts-nocheck
import { Helmet } from '@modern-js/runtime/head';
import Image from '../components/Image';
import './index.css';

const Index = () => (
  <div className="container-box">
    <Image />
  </div>
);

export default Index;
