# Nuxt Nest E-commerce Frontend
## Description

This is the main frontend (Customer-facing) for a fully functional & enterprise level Multi Vendor E-commerce platform built with NestJS for the server side & NuxtJS for the SSR enabled frontend