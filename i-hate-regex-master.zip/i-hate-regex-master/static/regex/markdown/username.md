Alphanumeric string that may include **\_ and -** having a length of **3 to 16** characters.
