import React from 'react';

export const metadata = {
  title: 'Logout',
};

function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

export default Layout;
