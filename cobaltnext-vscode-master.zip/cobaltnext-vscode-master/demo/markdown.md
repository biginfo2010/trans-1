# Cobalt Next Theme

> Cobalt Next theme for VS Code.

![Preview](../images/preview.png)

# Installation

1. Install [Visual Studio Code](https://code.visualstudio.com/)
2. Launch Visual Studio Code
3. Choose **Extensions** from menu
4. Search for `Cobalt Next`
5. Click **Install** to install it
6. Click **Reload** to reload the Code
7. File > Preferences > Color Theme > **Cobalt Next**
