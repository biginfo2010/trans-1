const serverRender = require('/Users/bytedance/outter/universe/apps/modernjs-ssr/nested-remote/dist/bundles/main.js');
console.log(33, serverRender);
