<template>
  <svg
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M3.83333 3.8335L2 5.66683L3.83333 7.50016"
      stroke="white"
      stroke-width="0.916667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M8.41675 3.8335L10.2501 5.66683L8.41675 7.50016"
      stroke="white"
      stroke-width="0.916667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.04159 2L5.20825 9.33333"
      stroke="white"
      stroke-width="0.916667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
