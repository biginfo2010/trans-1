const classes: { readonly test: string };

export default classes;
