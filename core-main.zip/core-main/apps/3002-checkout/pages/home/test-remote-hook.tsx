import TestRemoteHook from 'home/pages/home/test-remote-hook';
export default TestRemoteHook;
