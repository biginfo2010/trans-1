import CSimpleGrid from './CSimpleGrid'
export default CSimpleGrid
