'use client';

import { Title } from '@mantine/core';

export default Title;
