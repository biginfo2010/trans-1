<template>
  <div>
    <p class="text-gray-600 mt-5">
      no results
    </p>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
