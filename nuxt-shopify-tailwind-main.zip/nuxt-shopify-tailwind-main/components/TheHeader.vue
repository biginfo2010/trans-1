<template>
  <nav class="py-2 relative w-full">
    <div class="px-6">
        <NuxtLink to="/">
          <img class="h-20 w-20 mr-16" src="/logo.svg" alt="Store logo" />
        </NuxtLink>
    </div>
  </nav>
</template>