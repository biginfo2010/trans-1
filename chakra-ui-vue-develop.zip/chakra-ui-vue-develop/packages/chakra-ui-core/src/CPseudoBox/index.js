import CPseudoBox from './CPseudoBox'
export default CPseudoBox
