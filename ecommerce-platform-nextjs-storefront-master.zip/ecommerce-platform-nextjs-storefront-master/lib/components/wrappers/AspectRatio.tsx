'use client';

import { AspectRatio } from '@mantine/core';

export default AspectRatio;
