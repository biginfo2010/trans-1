---
"vue-demo-store": patch
---

Added loader to the changing payment method on the order details page. Added better UX for the change payment method modal
