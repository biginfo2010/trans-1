// @ts-ignore
import CheckoutTitlePage from 'checkout/pages/checkout/test-title';
export default CheckoutTitlePage;
