<template>
  <div class="flex-1 py-4 max-w-screen-2xl w-full px-4 mx-auto">
    <slot />
  </div>
</template>
