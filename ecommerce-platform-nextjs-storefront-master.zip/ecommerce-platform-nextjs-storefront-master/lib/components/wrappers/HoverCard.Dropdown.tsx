'use client';

import { HoverCard } from '@mantine/core';

export default HoverCard.Dropdown;
