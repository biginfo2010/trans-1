export { feUpload } from 'feather-icons-paths'
