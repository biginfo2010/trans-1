export const ReadableStream = null
