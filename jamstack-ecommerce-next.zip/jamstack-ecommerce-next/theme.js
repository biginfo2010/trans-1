const colors = {
  primary: '#89bdf9'
}

export {
  colors
}