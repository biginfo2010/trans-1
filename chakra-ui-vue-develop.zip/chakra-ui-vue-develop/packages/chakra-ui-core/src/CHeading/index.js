import CHeading from './CHeading'
export default CHeading
