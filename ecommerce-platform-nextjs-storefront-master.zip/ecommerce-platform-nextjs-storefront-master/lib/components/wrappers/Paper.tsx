'use client';

import { Paper } from '@mantine/core';

export default Paper;
