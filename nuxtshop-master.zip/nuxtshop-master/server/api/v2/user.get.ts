export default eventHandler(event => {
  const user = event.context.user
  return user
})
