import Vue from 'vue'
import VueFuse from 'vue-fuse'

Vue.use(VueFuse)
