<template>
  <svg viewBox="0 0 11 9" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M3.20833 2.66675L1.375 4.50008L3.20833 6.33341"
      stroke="currentColor"
      stroke-width="0.916667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.79175 2.66675L9.62508 4.50008L7.79175 6.33341"
      stroke="currentColor"
      stroke-width="0.916667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.41659 0.833252L4.58325 8.16659"
      stroke="currentColor"
      stroke-width="0.916667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
