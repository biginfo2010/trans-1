<template>
  <svg
    width="14"
    height="15"
    viewBox="0 0 14 15"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1 1H13V2.629C12.9999 3.02679 12.8418 3.40826 12.5605 3.6895L9.25 7V12.25L4.75 13.75V7.375L1.39 3.679C1.13909 3.40294 1.00004 3.0433 1 2.67025V1Z"
      stroke="currentColor"
      stroke-width="1.625"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
