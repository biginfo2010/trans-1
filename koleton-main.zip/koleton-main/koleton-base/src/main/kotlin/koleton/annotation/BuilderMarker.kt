package koleton.annotation

@DslMarker
@MustBeDocumented
@Retention(value = AnnotationRetention.BINARY)
annotation class BuilderMarker