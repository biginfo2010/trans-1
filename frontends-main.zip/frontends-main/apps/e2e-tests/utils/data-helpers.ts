export async function getRandomNumber() {
  return Math.floor(Math.random() * 10000 + 1);
}
