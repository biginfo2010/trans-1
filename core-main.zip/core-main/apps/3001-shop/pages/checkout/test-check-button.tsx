import CheckButtonPage from 'checkout/pages/checkout/test-check-button';

export default CheckButtonPage;
