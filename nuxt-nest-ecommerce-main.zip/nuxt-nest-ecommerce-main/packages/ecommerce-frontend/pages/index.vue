<script lang="ts" setup>
</script>

<template>
  <h1>Hello World Bitches</h1>
</template>
