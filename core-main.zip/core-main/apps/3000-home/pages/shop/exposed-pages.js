import ExposedPages from 'shop/pages/shop/exposed-pages';
export default ExposedPages;
