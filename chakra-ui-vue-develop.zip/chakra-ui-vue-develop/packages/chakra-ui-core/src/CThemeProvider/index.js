import CThemeProvider from './CThemeProvider'
export default CThemeProvider
