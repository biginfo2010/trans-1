import { useLocation } from '@remix-run/react';

export default () => {
    return useLocation();
};
