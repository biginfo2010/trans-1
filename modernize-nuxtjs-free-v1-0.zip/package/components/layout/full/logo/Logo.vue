<template>
  <LayoutFullLogoDark />
</template>
