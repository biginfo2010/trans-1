export type TemplateType = {}
