import CCheckbox from './CCheckbox'
export default CCheckbox
