export { default } from './BannerSlide'
