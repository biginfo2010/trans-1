A media access control address is a unique identifier assigned to a network interface controller for use as a network address within a network.

The expression is a 6 byte hexadecimal which is separated by `colon (:)` or a `dash (-)`.

