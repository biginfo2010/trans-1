export function validateEmpty(value: string): boolean {
  return value !== ""
}
