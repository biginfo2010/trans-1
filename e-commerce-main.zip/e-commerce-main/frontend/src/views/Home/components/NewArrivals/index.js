export { default } from './NewArrivals'
