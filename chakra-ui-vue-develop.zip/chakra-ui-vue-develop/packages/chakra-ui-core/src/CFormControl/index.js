import CFormControl from './CFormControl'
export default CFormControl
