export const CLOUDINARY = 'Cloudinary';
