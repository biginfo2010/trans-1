<script setup>
definePageMeta({
  middleware: () => "/",
});
</script>
