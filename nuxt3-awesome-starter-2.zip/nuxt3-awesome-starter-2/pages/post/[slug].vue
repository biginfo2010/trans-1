<script lang="ts" setup>
definePageMeta({
  layout: 'page',
})
</script>

<template>
  <LayoutPageWrapper>
    <AwesomeContentDoc empty-tip="Post im empty" />
  </LayoutPageWrapper>
</template>
