export * from "./GCPStructuredLog";
