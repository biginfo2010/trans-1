 E.164 numbers are formatted as: `[+] [country code] [subscriber number including area code]`

And can have a maximum of fifteen digits.