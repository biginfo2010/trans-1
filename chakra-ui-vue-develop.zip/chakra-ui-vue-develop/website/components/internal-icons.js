export { default as icons } from '@chakra-ui/vue/src/lib/internal-icons'
