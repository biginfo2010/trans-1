'use client';

import { Text } from '@mantine/core';

export default Text;
