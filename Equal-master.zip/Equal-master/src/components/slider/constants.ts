export const DEFAULT_STEP_POINT_HEIGHT = 8
export const DEFAULT_PROPS = {
  MIN: 0,
  MAX: 100,
  STEP: 1,
  VALUE: 0,
}
