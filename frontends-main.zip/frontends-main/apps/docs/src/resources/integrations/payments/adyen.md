---
head:
  - - meta
    - name: og:title
      content: Adyen Integration (Payments)
  - - meta
    - name: og:description
      content: "In this chapter you will learn how to integrate Adyen (Payments)."
  - - meta
    - name: og:image
      content: "https://frontends-og-image.vercel.app/Adyen%20Integration.png?fontSize=120px"
nav:
  position: 10
---

[<img src="../../../.assets/payment-icons/adyen.png" alt="Adyen Logo" class="mb-8 h-20" />](https://docs.adyen.com/)

<!-- load: ../../../../../examples/adyen-dropin-component/README.md -->
