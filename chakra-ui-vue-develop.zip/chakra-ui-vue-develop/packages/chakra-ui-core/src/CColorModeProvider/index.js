import CColorModeProvider from './CColorModeProvider'
export default CColorModeProvider
export * from './CColorModeProvider'
