This expression can be used to validate an url slug with only lowercase alphabet or numbers on each word. 

For example, in `https://github.com/geongeorge/i-hate-regex` , `i-hate-regex` is the slug.