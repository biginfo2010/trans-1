'use client';

import { Container } from '@mantine/core';

export default Container;
