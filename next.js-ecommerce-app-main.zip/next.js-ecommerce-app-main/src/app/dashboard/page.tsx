function DashboardPage() {
  return <div>dashboard</div>;
}

export default DashboardPage;
