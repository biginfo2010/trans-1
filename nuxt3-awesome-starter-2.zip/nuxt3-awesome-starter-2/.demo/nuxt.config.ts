export default defineNuxtConfig({
  devtools: { enabled: true },
  extends: [
    '@nuxt-awesome/theme',
  ]
})
