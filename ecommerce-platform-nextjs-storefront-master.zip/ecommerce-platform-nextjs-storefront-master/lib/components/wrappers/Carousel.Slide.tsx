'use client';

import { Carousel } from '@mantine/carousel';

export default Carousel.Slide;
