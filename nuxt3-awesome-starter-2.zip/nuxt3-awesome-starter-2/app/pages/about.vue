<template>
  <NuxtWelcome />
</template>
