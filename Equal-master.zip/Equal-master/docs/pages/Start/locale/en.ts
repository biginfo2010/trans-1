export default {
  title: 'Getting started',
  step1: {
    title: '1. Install with NPM or Yarn',
    description: '',
  },
  step2: {
    title: '2. Install Tailwind version 3.2+',
    description: 'To install Tailwind follow his official documentation:',
  },
  step3: {
    title: '3. Add Equal UI theme file to the',
    description: '',
  },
  step4: {
    title: '4. Use all components',
    description: '',
  },
  step4_1: {
    title: '4.1. Or individual components',
    description: '',
  },
  step5: {
    title: '5. Add Inter font',
    description:
      'Equal UI uses {0} font by {1}. The simplest way to add it via CDN:',
  },
}
