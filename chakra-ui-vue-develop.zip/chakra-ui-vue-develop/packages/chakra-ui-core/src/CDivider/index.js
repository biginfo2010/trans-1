import CDivider from './CDivider'
export default CDivider
