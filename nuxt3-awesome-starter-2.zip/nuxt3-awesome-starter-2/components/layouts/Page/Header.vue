<template>
  <div class="mb-4">
    <slot />
  </div>
</template>
