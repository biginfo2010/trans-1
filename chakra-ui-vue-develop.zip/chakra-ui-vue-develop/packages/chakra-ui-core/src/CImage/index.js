import CImage from './CImage'
export default CImage
