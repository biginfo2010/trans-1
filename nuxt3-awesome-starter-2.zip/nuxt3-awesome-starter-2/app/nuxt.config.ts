export default defineNuxtConfig({
  devtools: { enabled: true },
  extends: '../',
})
