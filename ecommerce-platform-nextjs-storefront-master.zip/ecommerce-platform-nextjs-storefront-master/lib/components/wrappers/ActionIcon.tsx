'use client';

import { ActionIcon } from '@mantine/core';

export default ActionIcon;
