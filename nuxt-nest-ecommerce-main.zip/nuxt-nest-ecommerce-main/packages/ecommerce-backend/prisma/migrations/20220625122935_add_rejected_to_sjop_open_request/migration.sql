-- AlterTable
ALTER TABLE "ShopOpenRequest" ADD COLUMN     "rejected" BOOLEAN NOT NULL DEFAULT false;
