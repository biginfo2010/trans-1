A hyphen word break is when a word is broken into 2 using a hyphen (`-`) to be continued in the next line

This is especially useful in scraping data when you wanna join hyphen seperated words