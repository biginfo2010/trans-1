import CAvatarGroup from './CAvatarGroup'
export default CAvatarGroup
