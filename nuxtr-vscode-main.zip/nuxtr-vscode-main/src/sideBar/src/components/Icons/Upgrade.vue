<template>
  <svg viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M3.79163 1.625V11.375M3.79163 1.625L5.41663 3.25M3.79163 1.625L2.16663 3.25M10.8333 9.75L9.20829 11.375M9.20829 11.375L7.58329 9.75M9.20829 11.375V1.625"
      stroke="currentColor"
      stroke-width="0.8125"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
