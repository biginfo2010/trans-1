export type Review = {
  id: number;
  user: string;
  content: string;
  rating: number;
  date: string;
};
