---
type: chapter
title: Synchronization
---
