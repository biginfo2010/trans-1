import png from '../public/webpack.png';

export default function WebpackPng() {
  return <img className="shop-webpack-png" src={png.src} alt="webpack png" />;
}
