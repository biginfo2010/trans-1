package pro.anton.averin.android.skeleton.data.net;

/**
 * Created by AAverin on 29.06.2014.
 */
public interface RestService {


}
