export async function setupExample() {}
