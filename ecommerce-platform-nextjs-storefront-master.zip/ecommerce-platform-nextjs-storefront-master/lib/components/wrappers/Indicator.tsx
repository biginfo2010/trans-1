'use client';

import { Indicator } from '@mantine/core';

export default Indicator;
