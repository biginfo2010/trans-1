'use client';

import { Rating } from '@mantine/core';

export default Rating;
