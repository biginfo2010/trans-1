package pro.anton.averin.android.skeleton.utils;

/**
 * Created by AAverin on 03.07.2014.
 */
public interface IntentParams {

}
