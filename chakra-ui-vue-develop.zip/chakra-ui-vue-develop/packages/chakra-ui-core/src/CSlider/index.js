import CSlider from './CSlider'
export default CSlider
export * from './CSlider'
