// ===============================|| Blank Layout ||=============================== //
<script setup lang="ts">
</script>
<template>
  <v-app>
    <NuxtPage  />
  </v-app>
</template>
