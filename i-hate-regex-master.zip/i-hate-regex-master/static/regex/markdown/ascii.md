The regular expression represents **all printable ASCII characters**.

ASCII code is the numerical representation of all the characters and the ASCII table extends from char `NUL`(Null) to `DEL`. 

The printable characters extend from `CODE 32 (SPACE)` to `CODE 126 (TILDE[~])`.
