package pro.anton.averin.android.skeleton.activities;

/**
 * Created by AAverin on 28-10-2014.
 */
public class MainActivity extends BaseActivity {
    @Override
    public String getScreenName() {
        return "MainActivity";
    }
}
