# Localizations

This folder contains the language files for the project. To add a new language or update the existing language files, you can create a Pull Request (PR) with the new or updated files. Please make sure to update all language files with the same changes.
Once your PR is approved, the new language files will be added to the project.
Thank you for contributing to the project!
