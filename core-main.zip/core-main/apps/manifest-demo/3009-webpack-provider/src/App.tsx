import LocalButton from './Button';
import React from 'react';

const App = () => (
  <div>
    <h1>Bi-Directional</h1>
    <h2>App 2</h2>
    <LocalButton />
  </div>
);

export default App;
