import ApplicationForm from '@/components/protected/account/store-application/ApplicationForm';

function StoreApplicationPage() {
  return (
    <div>
      <ApplicationForm />
    </div>
  );
}

export default StoreApplicationPage;
