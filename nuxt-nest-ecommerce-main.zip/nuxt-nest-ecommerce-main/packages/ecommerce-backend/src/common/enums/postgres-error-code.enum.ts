export enum PostgresErrorCodes {
  UniqueViolation = '23505',
}
