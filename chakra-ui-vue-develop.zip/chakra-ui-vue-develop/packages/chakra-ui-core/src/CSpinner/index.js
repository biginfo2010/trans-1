import Spinner from './CSpinner'
export default Spinner
