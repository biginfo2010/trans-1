<template>
  <div class="md:p-10 p-5">
    <div class="card m-auto w-96 bg-base-100 shadow-xl">
      <div class="card-body">
        <slot></slot>
      </div>
    </div>
  </div>
</template>
