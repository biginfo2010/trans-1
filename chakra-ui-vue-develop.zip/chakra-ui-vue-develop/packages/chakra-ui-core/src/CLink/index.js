import CLink from './CLink'
export default CLink
