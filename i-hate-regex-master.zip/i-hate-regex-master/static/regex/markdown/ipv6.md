It is a 128 bit alphanumeric address separated by colon `(:)`. It can even contain hexadecimal.

