# modernjs-ssr-nested-remote

## 0.1.34

### Patch Changes

- Updated dependencies [ad605d2]
  - @module-federation/modern-js@0.6.14

## 0.1.33

### Patch Changes

- @module-federation/modern-js@0.6.13

## 0.1.32

### Patch Changes

- @module-federation/modern-js@0.6.12

## 0.1.31

### Patch Changes

- @module-federation/modern-js@0.6.11

## 0.1.30

### Patch Changes

- @module-federation/modern-js@0.6.10

## 0.1.29

### Patch Changes

- @module-federation/modern-js@0.6.9

## 0.1.28

### Patch Changes

- @module-federation/modern-js@0.6.8

## 0.1.27

### Patch Changes

- @module-federation/modern-js@0.6.7

## 0.1.26

### Patch Changes

- @module-federation/modern-js@0.6.6

## 0.1.25

### Patch Changes

- @module-federation/modern-js@0.6.5

## 0.1.24

### Patch Changes

- @module-federation/modern-js@0.6.4

## 0.1.23

### Patch Changes

- Updated dependencies [81201b8]
  - @module-federation/modern-js@0.6.3

## 0.1.22

### Patch Changes

- Updated dependencies [541494d]
- Updated dependencies [2394e38]
  - @module-federation/modern-js@0.6.2

## 0.1.21

### Patch Changes

- @module-federation/modern-js@0.6.1

## 0.1.20

### Patch Changes

- @module-federation/modern-js@0.6.0

## 0.1.19

### Patch Changes

- @module-federation/modern-js@0.5.2

## 0.1.18

### Patch Changes

- @module-federation/modern-js@0.5.1

## 0.1.17

### Patch Changes

- @module-federation/modern-js@0.5.0

## 0.1.16

### Patch Changes

- Updated dependencies [88dec4e]
  - @module-federation/modern-js@0.4.0

## 0.1.15

### Patch Changes

- @module-federation/modern-js@0.3.5

## 0.1.14

### Patch Changes

- Updated dependencies [951d705]
  - @module-federation/modern-js@0.3.4

## 0.1.13

### Patch Changes

- @module-federation/modern-js@0.3.3

## 0.1.12

### Patch Changes

- Updated dependencies [85ae159]
  - @module-federation/modern-js@0.3.2

## 0.1.13

### Patch Changes

- @module-federation/modern-js@0.3.1

## 0.1.12

### Patch Changes

- Updated dependencies [fa37cc4]
  - @module-federation/modern-js@0.2.0
