# Nuxt-Mart

Welcome to **Nuxt-Mart**, a minimal e-commerce application built with Nuxt.js & Tailwind CSS. This project serves as a starter template for developing modern web applications with a focus on performance and SEO.

## Features

- Server-side rendering for improved SEO and performance
- Modular architecture with components, composables, layouts, and pages
- Fully Responsive
- Easy setup and development environment

## Setup

To get started, clone the repository and install the dependencies:

```bash
git clone https://github.com/Rafeeuzzaman-Dihan/Nuxt-Mart.git
cd Nuxt-Mart

# npm
npm install

# pnpm
pnpm install

# yarn
yarn install

# bun
bun install
```

## Development Server

Start the development server on `http://localhost:3000`:

```bash
# npm
npm run dev

# pnpm
pnpm dev

# yarn
yarn dev

# bun
bun run dev
