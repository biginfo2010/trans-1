export type Category = {
  title: string;
  id: number;
  img: string;
};
