export default 'async file';
