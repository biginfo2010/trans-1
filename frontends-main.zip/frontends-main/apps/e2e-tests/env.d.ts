interface Window {
  StackBlitzSDK: typeof import("@stackblitz/sdk").default;
}

type StackBlitzSDK = typeof import("@stackblitz/sdk").default;
