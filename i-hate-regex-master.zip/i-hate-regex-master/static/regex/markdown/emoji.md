
Unicode standards published a list of all [emoji data](https://www.unicode.org/Public/emoji/12.1/emoji-data.txt)


> In 2015, Oxford Dictionaries named the Face with Tears of Joy emoji (😂) the **Word of the Year**