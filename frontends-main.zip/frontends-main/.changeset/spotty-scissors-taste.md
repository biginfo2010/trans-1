---
"@shopware/cms-base-layer": patch
---

SwVariantConfigurator - URL prefix on Variant Change
