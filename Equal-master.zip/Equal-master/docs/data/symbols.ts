export const uiConfig = Symbol.for('uiConfig')
export const initialUIConfig = Symbol.for('initialUIConfig')
