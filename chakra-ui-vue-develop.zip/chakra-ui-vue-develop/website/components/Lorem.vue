<template>
  <p>
    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vero eaque optio, nam nulla praesentium eos perferendis iusto nesciunt ipsa harum!
  </p>
</template>

<script>
export default {
  name: 'Lorem'
}
</script>
