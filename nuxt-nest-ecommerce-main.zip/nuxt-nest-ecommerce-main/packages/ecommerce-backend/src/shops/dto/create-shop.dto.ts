export class CreateShopDto {}
