import Shop from 'shop/pages/shop/index';
const Page = Shop;
Page.getInitialProps = Shop.getInitialProps;
export default Page;
