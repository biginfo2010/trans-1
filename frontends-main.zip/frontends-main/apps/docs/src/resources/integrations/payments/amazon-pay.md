---
head:
  - - meta
    - name: og:title
      content: Amazon Pay (Payments)
  - - meta
    - name: og:description
      content: "In this chapter you will learn how to integrate Amazon Pay Button (Payments)."
  - - meta
    - name: og:image
      content: "https://frontends-og-image.vercel.app/**Amazon%20Pay**%20Integration.png?fontSize=120px"
nav:
  position: 10
---

[<img src="../../../.assets/payment-icons/amazon-pay.png" alt="Adyen Logo" class="mb-8 h-20" />](https://developer.amazon.com/docs/amazon-pay/intro.html)

<!-- load: ../../../../../examples/amazon-pay-button-example/README.md -->
