import { ErrorCard } from '@/components/shared/ui';

function AuthErrorPage() {
  return <ErrorCard />;
}

export default AuthErrorPage;
