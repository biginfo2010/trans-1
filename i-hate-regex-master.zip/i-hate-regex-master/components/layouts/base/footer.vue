<template>
  <div>
    <div class="flex bg-gray-300 mt-6 h-24 w-full shadow-inner">
      <div class="flex-auto">
        <div class="flex flex-col h-full justify-center items-left ml-4">
          <div class="px-2 text-3xl text-gray-400">
            i<span class="font-bold">Hate</span>Regex
          </div>
          <div class="px-2 text-gray-500">
            by
            <a href="https://twitter.com/geongeorgek" class="underline" target="_blank">geon</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style>

</style>
