<template>
  <section>
    <img
      src="https://mdbootstrap.com/img/new/textures/full/142.jpg"
      class="h-[500px] w-full"
    />

    <div class="mx-auto px-32">
      <div
        class="text-7xl font-bold text-center text-gray-800 rounded-lg shadow-lg py-16 px-12 bg-white/70 -mt-[170px] backdrop-blur-xl"
      >
        <h1 class="mb-3">Find the best products</h1>
        <span class="text-green-600">on the market</span>
      </div>
    </div>
  </section>
</template>
