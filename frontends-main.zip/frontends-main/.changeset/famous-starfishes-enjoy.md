---
"vue-demo-store": patch
---

Add missing formatLink for links in checkout and my account page
