<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
  
</template>

<script setup>
import '@/assets/main.css';
</script>