The identifiers are the names given to variables, structures, functions etc in programming languages like C. 

An identifier can have **alphabets, numbers, and underscore (_)**.

Identifiers cannot start with numbers.

**Note:** Keywords cannot be used as an identifier