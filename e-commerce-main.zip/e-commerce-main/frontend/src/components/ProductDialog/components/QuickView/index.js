export { default } from './QuickView'
