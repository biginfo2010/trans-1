<template>
  <ul class="flex flex-wrap mt-4 -mx-2">
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/username">
          <p>username</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/phone">
          <p>phone number</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/email">
          <p>email</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/date">
          <p>date</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/ascii">
          <p>ascii</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/password">
          <p>password</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/ip">
          <p>ip address</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/ipv6">
          <p>ipv6</p>
        </nuxt-link>
      </div>
    </li>
    <li class="w-1/2 sm:w-1/3 md:w-1/3 px-2 mt-2">
      <div class="text-gray-600 hover:underline">
        <nuxt-link to="/expr/ssn">
          <p>ssn</p>
        </nuxt-link>
      </div>
    </li>
  </ul>
</template>

<script>
export default {}
</script>

<style></style>
