import TestSvg from 'shop/pages/shop/test-webpack-svg';
export default TestSvg;
