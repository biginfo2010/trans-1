import CSwitch from './CSwitch'
export default CSwitch
