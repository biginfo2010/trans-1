<template>
    <div class="container mt-custom mb-5">
        <div class="fade-in">
            <div class="row mt-5 pt-5">
                <div class="col-md-4 mb-4">
                    <div class="card border-0 rounded shadow-sm">
                        <div class="card-body">
                            <img src="~assets/images/aa.jpg" class="w-100 rounded" alt="Company Photo">
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card border-0 rounded shadow-sm">
                        <div class="card-body">
                            <h3 class="card-title">E-commerce</h3>
                            <p class="card-text">
                                Analisis dan Perancangan Sistem Informasi Penjualan Online Toko Sepatu
                            </p>
                            <p class="card-text">
                               <ol>
                                <li>Rizki Nugroho</li>

                            </p>
                            <p class="card-text">
                                Tujuan nya adalah membuat
                                website toko online berbasis ecommerce yang dapat diakses secara
                                online, promosi produk melalui website sebagai media promosi yang
                                efektif dan efisien, memudahkan perusahaan dalam pembuatan laporan
                                secara digital sehingga menjadi efisien dan praktis, dan informasi produk
                                terupdate secara digital melalui website sebagai media informasi kepada
                                pelanggan.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    head() {
        return {
            title: 'About Us - SHOE STORE',
        }
    }
}
</script>

<style scoped>
.mt-custom {
    margin-top: 100px;
}

.card-title {
    font-size: 2.5rem;
    font-weight: bold;
    margin-bottom: 1rem;
    color: #333;
}

.card-text {
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 1rem;
    color: #555;
}
</style>
