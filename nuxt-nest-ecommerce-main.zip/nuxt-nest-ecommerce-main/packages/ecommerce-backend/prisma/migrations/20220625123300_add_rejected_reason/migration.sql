-- AlterTable
ALTER TABLE "ShopOpenRequest" ADD COLUMN     "rejectedReason" TEXT;
