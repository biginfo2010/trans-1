export { default } from './ErrorBoundary'
