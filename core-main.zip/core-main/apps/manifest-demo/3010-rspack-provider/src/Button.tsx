const style = {
  background: '#f00505',
  color: '#fff',
  padding: 12,
};

const Button = () => <button style={style}>3010-remote2 Button</button>;

export default Button;
