#!/bin/sh
cd /i-hate-regex/
yarn start
