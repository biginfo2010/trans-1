import CEditable from './CEditable'
export default CEditable
export * from './CEditable'
