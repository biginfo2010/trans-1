import CheckoutTitle from '../../components/CheckoutTitle';

export default function CheckoutTitlePage() {
  return (
    <div>
      <CheckoutTitle />
    </div>
  );
}
