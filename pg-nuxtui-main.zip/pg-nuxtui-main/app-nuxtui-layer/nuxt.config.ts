export default defineNuxtConfig({})
