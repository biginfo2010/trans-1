import { defineConfig } from "@tutorialkit/theme";

export default defineConfig({
  // add your UnoCSS config here: https://unocss.dev/guide/config-file
});
