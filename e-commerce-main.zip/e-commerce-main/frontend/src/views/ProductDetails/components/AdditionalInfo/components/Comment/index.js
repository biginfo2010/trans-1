export { default } from './Comment'
