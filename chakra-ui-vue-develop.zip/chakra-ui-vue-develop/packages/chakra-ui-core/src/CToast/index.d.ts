import CToast from './CToast'
export default CToast
