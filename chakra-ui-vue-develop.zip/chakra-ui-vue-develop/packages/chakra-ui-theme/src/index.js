import ChakraUITheme from './theme'
export default ChakraUITheme
