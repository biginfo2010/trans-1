import React from 'react';

export const Button = () => {
  return (
    <>
      <button>button from remote</button>
    </>
  );
};
