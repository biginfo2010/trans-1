'use client';

import { Button } from '@mantine/core';

export default Button;
