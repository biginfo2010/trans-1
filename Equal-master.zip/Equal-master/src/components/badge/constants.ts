import { Positions } from '@/models/enums'

export const ALLOWED_POSITIONS = [
  Positions.TL,
  Positions.TR,
  Positions.BL,
  Positions.BR,
]
