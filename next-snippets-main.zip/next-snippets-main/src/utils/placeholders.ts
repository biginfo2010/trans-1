export const fileNameCapitalized = "fileCapitalized";
export const fileName = "fileName";
export const first = "first";
export const second = "second";
export const third = "third";
