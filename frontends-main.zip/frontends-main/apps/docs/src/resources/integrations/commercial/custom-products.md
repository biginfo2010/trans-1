---
head:
  - - meta
    - name: og:title
      content: Custom Products Integration
  - - meta
    - name: og:description
      content: "In this chapter you will learn how to integrate Custom Products."
  - - meta
    - name: og:image
      content: "https://frontends-og-image.vercel.app/Custom%20Products.png?fontSize=120px"
nav:
  position: 30
---

<!-- load: ../../../../../examples/commercial-customized-products/README.md -->
