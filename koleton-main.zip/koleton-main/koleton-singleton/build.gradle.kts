dependencies {
    api(project(":koleton-base"))
    implementation(Dependencies.androidRecyclerView)
}
