<template>
  <div
    class="card-footer duration-300 transition-colors px-6 py-2 text-sm bg-white dark:bg-gray-950 border-t border-gray-950/10 dark:border-gray-50/[0.2]"
  >
    <slot />
  </div>
</template>
