import React from 'react';

const style = {
  background: '#00c',
  color: '#fff',
  padding: 12,
};

const Button = () => <button style={style}>3009-remote1 Button</button>;

export default Button;
