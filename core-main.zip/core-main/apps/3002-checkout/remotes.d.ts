declare module 'home/SharedNav';
declare module 'home/pages/home/exposed-pages';
declare module 'home/pages/home/test-broken-remotes';
declare module 'home/pages/home/test-remote-hook';
declare module 'home/pages/home/test-shared-nav';
