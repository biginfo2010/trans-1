export type Topic = {
    name: string;
    path: string;
};
