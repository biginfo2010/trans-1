'use client';

import { Space } from '@mantine/core';

export default Space;
