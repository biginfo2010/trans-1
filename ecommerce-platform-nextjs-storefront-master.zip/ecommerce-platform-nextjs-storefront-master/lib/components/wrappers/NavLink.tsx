'use client';

import { NavLink } from '@mantine/core';

export default NavLink;
