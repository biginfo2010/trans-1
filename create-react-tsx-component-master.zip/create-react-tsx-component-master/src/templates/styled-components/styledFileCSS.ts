export default () =>
  `/* The component style is inserted here. */
`;
