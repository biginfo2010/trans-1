import { ProductSlim } from './Product';

export type ProductListHostpot = {
    products: ProductSlim[];
    x: number;
    y: number;
};
