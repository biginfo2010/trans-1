This expression can be used to find or validate a date field and the most accepted form of date can have DD-MM-YYYY format with the seperators: `-` , `/` and `.`

