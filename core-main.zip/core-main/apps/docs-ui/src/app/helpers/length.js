'use strict';

module.exports = (val) => (val ? val.length : 0);
