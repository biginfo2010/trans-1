<template>
  Surpressing Nuxt error in console by including this file... Not sure why it's
  a thing
</template>
