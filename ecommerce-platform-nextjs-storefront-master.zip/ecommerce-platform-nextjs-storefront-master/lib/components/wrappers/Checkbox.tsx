'use client';

import { Checkbox } from '@mantine/core';

export default Checkbox;
