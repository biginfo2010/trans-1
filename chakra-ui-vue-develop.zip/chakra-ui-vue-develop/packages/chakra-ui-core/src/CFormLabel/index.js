import CFormLabel from './CFormLabel'
export default CFormLabel
