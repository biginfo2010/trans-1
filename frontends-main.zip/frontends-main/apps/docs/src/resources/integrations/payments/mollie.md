---
head:
  - - meta
    - name: og:title
      content: mollie Integration (Payments)
  - - meta
    - name: og:description
      content: "In this chapter you will learn how to integrate mollie (Payments)."
  - - meta
    - name: og:image
      content: "https://frontends-og-image.vercel.app/mollie%20Integration.png?fontSize=120px"
nav:
  position: 20
---

[<img src="../../../.assets/payment-icons/mollie.webp" alt="mollie Logo" class="mb-8 h-20" />](https://docs.mollie.com/)

<!-- load: ../../../../../examples/mollie-credit-card/README.md -->
