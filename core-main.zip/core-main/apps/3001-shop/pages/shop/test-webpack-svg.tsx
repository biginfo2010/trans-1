import WebpackSvg from '../../components/WebpackSvg';

export default function WebpackSvgPage() {
  return <WebpackSvg />;
}
