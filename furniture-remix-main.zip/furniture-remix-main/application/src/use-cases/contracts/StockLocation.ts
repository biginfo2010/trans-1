export type StockLocation = {
    identifier: string;
    name: string;
    stock: number;
};
