'use client';

import { Flex } from '@mantine/core';

export default Flex;
