import CText from './CText'
export default CText
