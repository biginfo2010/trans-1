# node-dynamic-remote

## null

### Patch Changes

- @module-federation/node@2.2.12

## null

### Patch Changes

- @module-federation/node@2.2.11

## null

### Patch Changes

- @module-federation/node@2.2.10

## null

### Patch Changes

- @module-federation/node@2.2.9

## null

### Patch Changes

- @module-federation/node@2.2.8

## null

### Patch Changes

- @module-federation/node@2.2.7

## null

### Patch Changes

- @module-federation/node@2.2.6

## null

### Patch Changes

- Updated dependencies [450c224]
  - @module-federation/node@2.2.5

## null

### Patch Changes

- Updated dependencies [890fff8]
  - @module-federation/node@2.2.4
