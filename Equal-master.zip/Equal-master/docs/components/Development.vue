<template>
  <div class="relative z-0 flex flex-1 flex-col">
    <div class="fancybox"></div>
    <div
      class="fancy-shadow relative flex-1 items-center justify-center rounded bg-white px-4 py-16 dark:border-black dark:bg-zinc-800"
    >
      <h1
        class="mb-2 bg-gradient-to-r from-rose-400 via-fuchsia-500 to-indigo-500 bg-clip-text text-center text-2xl font-bold text-transparent"
      >
        Magic happens here
      </h1>
      <h2 class="text-md text-center text-zinc-400">
        This component is in development
      </h2>
      <h2 class="text-md text-center text-zinc-400">Coming with 1.0</h2>
    </div>
  </div>
</template>
