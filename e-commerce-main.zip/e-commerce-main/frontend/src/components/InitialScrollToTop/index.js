export { default } from './InitialScrollToTop'
