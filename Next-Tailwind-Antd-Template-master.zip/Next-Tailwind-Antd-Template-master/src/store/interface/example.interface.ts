export interface IExampleState {
  counter: number
  setCounter: (counter: number) => void
}