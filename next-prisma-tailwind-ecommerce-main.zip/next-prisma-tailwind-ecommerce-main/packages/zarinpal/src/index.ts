import { query } from './query'

export { query }
