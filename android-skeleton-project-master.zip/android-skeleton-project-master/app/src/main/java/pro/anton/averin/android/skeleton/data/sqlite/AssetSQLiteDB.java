package pro.anton.averin.android.skeleton.data.sqlite;

/**
 * Created by AAverin on 11-12-2014.
 */
public class AssetSQLiteDB {
//        extends BaseSQLiteDB {

//    private AssetDBHelper helper = null;
//
//    public AssetSQLiteDB(Context context, String name, int version) {
//        super(context, name, version);
//    }
//
//    @Override
//    public SQLiteOpenHelper getHelper() {
//        if (helper == null) {
//            helper = new AssetDBHelper(context);
//            helper.getWritableDatabase(); //results in db onCreate being called
//        }
//        return helper;
//    }
//
//    @Override
//    public void close() {
//        helper.close();
//    }
//
//    protected class AssetDBHelper extends SQLiteAssetHelper {
//        AssetDBHelper(Context context) {
//            super(context, dbName, null, dbVersion);
//        }
//    }

}