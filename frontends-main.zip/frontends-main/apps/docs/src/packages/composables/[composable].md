# {{NAME}}

<div class="mb-10 grid grid-cols-[80px_auto] gap-2 text-sm">
{{META}}
</div>

{{DESCRIPTION}}

{{ADDITIONAL_README}}

{{DEMO_BLOCK}}

## Types

{{INTERFACE_CONTENT}}

{{RETURN_TYPES_CONTENT}}
