'use client';

import { List } from '@mantine/core';

export default List.Item;
