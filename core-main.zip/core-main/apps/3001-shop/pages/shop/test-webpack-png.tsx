import WebpackPng from '../../components/WebpackPng';

export default function WebpackPngPage() {
  return <WebpackPng />;
}
