<template>
    <div class="has-background-light">
      <p>
        This is the default error layout. You can customize it by editing the file at
        <code>layouts/default.vue</code>
      </p>
      <slot />
    </div>
  </template>
  
  <script setup>
  
  </script>
  
  <style></style>
  