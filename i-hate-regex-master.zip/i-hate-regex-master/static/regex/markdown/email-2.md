Strict validation of email.

Although it's up for debate often, It's better to use simpler expressions whenever possible. 

Check out a shorter - [email regex](/expr/email)