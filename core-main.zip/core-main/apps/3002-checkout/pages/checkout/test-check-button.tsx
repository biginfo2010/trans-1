import ButtonOldAnt from '../../components/ButtonOldAnt';

export default function CheckButtonPage() {
  return (
    <div>
      <ButtonOldAnt />
    </div>
  );
}
