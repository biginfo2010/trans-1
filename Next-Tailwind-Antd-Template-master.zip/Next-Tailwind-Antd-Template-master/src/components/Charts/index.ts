import ExampleChart from "@/components/Charts/ExampleChart"

export {
  ExampleChart
}
