export type Item = {
    name: string;
    path: string;
};
