export default {
  wip: 'This page is WIP',
  own_theme_copy:
    'To create your own theme you can copy on of the initial theme files and make your changes to them:',
  own_theme: 'Or make your own theme file from scratch',
  full: 'contains classes for light and dark themes',
  light: 'contains classes for light theme',
  dark: 'contains classes for dark theme',
}
